package blog;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class BlogDAO {

	private Connection conn;
	private PreparedStatement pstmt;
	private ResultSet rs;
		
	//		---------- DB���� ----------  //
	public BlogDAO() {
		try {
			String dbURL = "jdbc:mysql://localhost:3306/blog";//mysql ��ġ
			String dbID = "root";//mysql ID
			String dbPassword = "root";//mysql PASSWORD
			Class.forName("com.mysql.cj.jdbc.Driver");//���� ����̹�
			conn=DriverManager.getConnection(dbURL, dbID, dbPassword);//DB�������� �� ����
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	//���
	public ArrayList<Blog> getList(){
		String SQL = "SELECT * FROM blog ORDER BY num DESC";                        
		ArrayList<Blog> list = new ArrayList<Blog>();
		try {
			PreparedStatement pstmt=conn.prepareStatement(SQL);
			//pstmt.setInt(1, getNext() - (pageNumber-1)*10);
			//pstmt.setInt(1, recordCount() - (recordCount()-(pageNumber-1)*10));
			rs=pstmt.executeQuery();
			while(rs.next()) {
				Blog blog = new Blog();
				blog.setNum(rs.getInt(1));
				blog.setTitle(rs.getString(2));
				list.add(blog);
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}
	
	//���� �б�
		public Blog getBlog(int memberNum) {
			String SQL = "SELECT * FROM blog WHERE num = ?";
			try {
				PreparedStatement pstmt=conn.prepareStatement(SQL);
				pstmt.setInt(1,memberNum);
				rs=pstmt.executeQuery();
				if(rs.next()) {
					Blog blog = new Blog();
					blog.setNum(rs.getInt(1));
					blog.setTitle(rs.getString(2));
					blog.setContent(rs.getString(3));
					blog.setImgAddress(rs.getString(4));
					return blog;
				}
			}catch (Exception e) {
				e.printStackTrace();
			}
			return null;
			
		}
	
	//������ �� ������ȣ ���ϱ�
	public int getNext() {
		String SQL = "SELECT num FROM blog ORDER BY num DESC";
		try {
			PreparedStatement pstmt=conn.prepareStatement(SQL);
			rs=pstmt.executeQuery();
			if(rs.next()) {
				return rs.getInt(1) + 1;//������ȣ
			}else {
				return 1;//���۹�ȣ
			}			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return -1;//������ȣ
	}
		
	//������ �޼ҵ�
		public int write(String Title, String Content) {
			String SQL = "INSERT INTO blog VALUES(?,?,?,null)";
			try {
				PreparedStatement pstmt=conn.prepareStatement(SQL);
				pstmt.setInt(1, getNext());
				pstmt.setString(2, Title);
				pstmt.setString(3, Content);
				return pstmt.executeUpdate();
			}catch (Exception e) {
				e.printStackTrace();
			}
			return -1;//�����ͺ��̽� ����
		}

}